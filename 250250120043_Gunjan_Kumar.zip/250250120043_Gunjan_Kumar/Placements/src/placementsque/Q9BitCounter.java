package placementsque;


public class Q9BitCounter {

    public static int countSetBits(int number) {
        int count = 0;
        while (number != 0) {
            count += number & 1;  
            number >>>= 1;        
        }
        return count;
    }

    public static void main(String[] args) {
        int num = 64;
        System.out.println("Number of set bits in " + num + " is: " + countSetBits(num));
    }
}