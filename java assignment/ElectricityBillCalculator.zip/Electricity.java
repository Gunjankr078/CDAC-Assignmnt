package classObject;
import java.util.Scanner;

public class Electricity {
	
		int customerNumber;
		String customerName;
		double unitsConsumed;
		
		public void readData() {
			Scanner s = new Scanner(System.in);
			
			System.out.println("Enter Customer Id/No: ");
			customerNumber = s.nextInt();
			
			System.out.println("Enter Costumer Name: ");
			customerName = s.next();
			
			System.out.println("Enter Units Consumed : ");
			unitsConsumed = s.nextDouble();
			
		}
		
		public void showData() {
			System.out.println("Custumer Id: " +customerNumber);
			System.out.println("Custumer Name: " +customerName);
			System.out.println("Units Consumed By Customer: " +unitsConsumed);
		}
		
	    public double computeBill() {
	        double bill = 0;
	        double units = unitsConsumed;

	        if (units <= 100) {
	            bill = units * 1.20;
	        } else if (units <= 300) {
	            bill = 100 * 1.20 + (units - 100) * 2.00;
	        } else if (units <= 600) {
	            bill = 100 * 1.20 + 200 * 2.00 + (units - 300) * 3.00;
	        } else {
	            bill = 100 * 1.20 + 200 * 2.00 + 300 * 3.00 + (units - 600) * 5.00;
	        }

	        return bill;
	    }
	    
	    
	}
