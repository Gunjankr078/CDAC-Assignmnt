package classObject;

public class Mian {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Electricity e1 = new Electricity();
		System.out.println("Enter details of the cosumer:");
		e1.readData();
		
		Electricity e2 = new Electricity();
		System.out.println("Enter details of the cosumer:");
		e2.readData();

		Electricity e3 = new Electricity();
		System.out.println("Enter details of the cosumer:");
		e3.readData();
		
		System.out.println("\n1st Consumer details:");
        e1.showData();
        System.out.printf("Total Bill: Rs. %.2f\n", e1.computeBill());

        System.out.println("\n2nd Consumer details:");
        e2.showData();
        System.out.printf("Total Bill: Rs. %.2f\n", e2.computeBill());

        System.out.println("\n3rd Consumer details:");
        e3.showData();
        System.out.printf("Total Bill: Rs. %.2f\n", e3.computeBill());

	}

}
