package classObject;

import java.util.Scanner;

public class Employee {
	int empno;
	String empname;
	String empDesig;
	String dept;
	double salary;
	
	public void readEmployee() {
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter Employee No: ");
		empno = s.nextInt();
		
		System.out.println("Enter Employee Name: ");
		empname = s.next();
		
		System.out.println("Enter Employee Designation : ");
		empDesig = s.next();
		
		System.out.println("Enter Employee Department : ");
		dept = s.next();
		
		System.out.println("Enter Employee Salary : $");
		salary = s.nextDouble();
		
	}
	
	public void displayEmployee() {
		System.out.println("Employee No: " +empno);
		System.out.println("Employee Name: " +empname);
		System.out.println("Employee Designation: " +empDesig);
		System.out.println("Employee Department: " +dept);
		System.out.println("Employee Salary: " +salary);
		
		
	}
	
/*	public void initializeEmp(int id,String na,String desig,String dep, double sa)
	{
		empno = id;
		empname = na;
		empDesig = desig;
		dept = dep;
		salary = sa;
			
	}*/
	
}
