package classObject;

public class Main {
    public static void main(String[] args) {
        // Create the first Employee object and read data from the user
        Employee e1 = new Employee();
        System.out.println("Enter details for the first employee:");
        e1.readEmployee();
        System.out.println("First employee details:");
        e1.displayEmployee();

        // Create the second Employee object and read data from the user
        Employee e2 = new Employee();
        System.out.println("\nEnter details for the second employee:");
        e2.readEmployee();
        System.out.println("Second employee details:");
        e2.displayEmployee();
        
        Employee e3 = new Employee();
        System.out.println("\nEnter details for the third employee:");
        e3.readEmployee();
        System.out.println("Third employee details:");   
        e3.displayEmployee();
        
    }
}