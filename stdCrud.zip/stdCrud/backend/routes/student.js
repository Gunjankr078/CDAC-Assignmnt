const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Helper function to check if email exists (excluding a given student ID for update)
function checkEmailExists(email, excludeId = null) {
  return new Promise((resolve, reject) => {
    let query = 'SELECT id FROM students WHERE email = ?';
    const params = [email];

    if (excludeId) {
      query += ' AND id != ?';
      params.push(excludeId);
    }

    db.query(query, params, (err, results) => {
      if (err) return reject(err);
      resolve(results.length > 0);
    });
  });
}

// Create a new student
router.post('/', async (req, res) => {
  const { name, email, course, address, mobile_no, dob } = req.body;

  try {
    const exists = await checkEmailExists(email);
    if (exists) {
      return res.status(400).json({ error: 'Email already exists' });
    }

    const sql = 'INSERT INTO students (name, email, course, address, mobile_no, dob) VALUES (?, ?, ?, ?, ?, ?)';
    db.query(sql, [name, email, course, address, mobile_no, dob], (err, result) => {
      if (err) return res.status(500).json(err);
      res.status(201).json({ id: result.insertId, name, email, course, address, mobile_no, dob });
    });
  } catch (err) {
    res.status(500).json(err);
  }
});

// Get all students
router.get('/', (req, res) => {
  const sql = 'SELECT * FROM students';
  db.query(sql, (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
});

// Update a student
router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { name, email, course, address, mobile_no, dob } = req.body;

  try {
    const exists = await checkEmailExists(email, id);
    if (exists) {
      return res.status(400).json({ error: 'Email already exists' });
    }

    const sql = 'UPDATE students SET name = ?, email = ?, course = ?, address = ?, mobile_no = ?, dob = ? WHERE id = ?';
    db.query(sql, [name, email, course, address, mobile_no, dob, id], (err) => {
      if (err) return res.status(500).json(err);
      res.json({ id, name, email, course, address, mobile_no, dob });
    });
  } catch (err) {
    res.status(500).json(err);
  }
});

// Delete a student
router.delete('/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM students WHERE id = ?';
  db.query(sql, [id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Student deleted' });
  });
});

module.exports = router;


