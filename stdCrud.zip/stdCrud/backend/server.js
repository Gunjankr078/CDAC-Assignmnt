const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const studentRoutes = require('./routes/student'); // Ensure this path is correct

const app = express();
const PORT = 5000;

app.use(cors());
app.use(bodyParser.json());
app.use('/api/students', studentRoutes); // Ensure studentRoutes is a function

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
