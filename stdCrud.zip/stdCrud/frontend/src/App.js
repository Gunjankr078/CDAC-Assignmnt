import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import StudentList from './components/StudentList';
import StudentForm from './components/StudentForm';
import api from './services/api';

const courses = [
  'PG-DAC',
  'PG-DBDA',
  'PG-DESD',
  'PG-DIoT',
  'PG-DAI',
];

function App() {
  const [students, setStudents] = useState([]);
  const [editingStudent, setEditingStudent] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [apiErrors, setApiErrors] = useState({});

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    try {
      const res = await api.get('/');
      setStudents(res.data);
    } catch (error) {
      alert('Failed to fetch students');
    }
  };

  const addStudent = async (student) => {
    try {
      setApiErrors({});
      const res = await api.post('/', student);
      setStudents([...students, res.data]);
      setShowForm(false);
    } catch (error) {
      if (error.response?.status === 400 && error.response.data.error) {
        setApiErrors({ email: error.response.data.error });
      } else {
        alert('Failed to add student');
      }
    }
  };

  const updateStudent = async (student) => {
    try {
      setApiErrors({});
      const res = await api.put(`/${student.id}`, student);
      setStudents(students.map(s => (s.id === student.id ? res.data : s)));
      setEditingStudent(null);
      setShowForm(false);
    } catch (error) {
      if (error.response?.status === 400 && error.response.data.error) {
        setApiErrors({ email: error.response.data.error });
      } else {
        alert('Failed to update student');
      }
    }
  };

  const deleteStudent = async (id) => {
    if (!window.confirm('Are you sure want to delete this student?')) return;
    try {
      await api.delete(`/${id}`);
      setStudents(students.filter(s => s.id !== id));
    } catch (error) {
      alert('Failed to delete student');
    }
  };

  const onEditClick = (student) => {
    setEditingStudent(student);
    setShowForm(true);
  };

  const onAddClick = () => {
    setEditingStudent(null);
    setApiErrors({});
    setShowForm(true);
  };

  const onCancel = () => {
    setEditingStudent(null);
    setApiErrors({});
    setShowForm(false);
  };

  return (
    <div className="container my-4" style={{ maxWidth: '600px' }}>
      <h2 className="text-center mb-4">Student Record Management</h2>
      {!showForm && (
        <div className="d-flex justify-content-end mb-3">
          <button className="btn btn-primary" onClick={onAddClick}>Add New Student</button>
        </div>
      )}
      {showForm ? (
        <StudentForm
          courses={courses}
          student={editingStudent}
          onCancel={onCancel}
          onSubmit={editingStudent ? updateStudent : addStudent}
          apiErrors={apiErrors}
        />
      ) : (
        <StudentList
          students={students}
          onEdit={onEditClick}
          onDelete={deleteStudent}
        />
      )}
      <footer className="text-center text-muted mt-5 mb-3" style={{ fontSize: '0.875rem' }}>
        © 2025 WebTechnoloies(CDAC)
      </footer>
    </div>
  );
}

export default App;

/*Create a Student: POST http://localhost:5000/api/students
Read All Students: GET http://localhost:5000/api/students
Read a Single Student: GET http://localhost:5000/api/students/:id
Update a Student: PUT http://localhost:5000/api/students/:id
Delete a Student: DELETE http://localhost:5000/api/students/:id */