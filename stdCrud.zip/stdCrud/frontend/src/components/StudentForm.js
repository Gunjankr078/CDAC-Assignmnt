import React, { useState, useEffect } from 'react';

const nameRegex = /^[A-Za-z ]+$/;
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const addressRegex = /^[A-Za-z0-9\s,.'-]{3,}$/;
const mobileRegex = /^[0-9]{10,15}$/;

function StudentForm({ courses, student, onCancel, onSubmit, apiErrors }) {
  const [form, setForm] = useState({
    name: '',
    email: '',
    course: '',
    address: '',
    mobile_no: '',
    dob: '',
  });

  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (student) {
      setForm({
        name: student.name || '',
        email: student.email || '',
        course: student.course || '',
        address: student.address || '',
        mobile_no: student.mobile_no || '',
        dob: student.dob ? student.dob.slice(0, 10) : '',
      });
    } else {
      setForm({
        name: '',
        email: '',
        course: '',
        address: '',
        mobile_no: '',
        dob: '',
      });
    }
    setErrors({});
  }, [student]);

  const validate = () => {
    const errs = {};
    if (!form.name.trim()) {
      errs.name = 'Name is required';
    } else if (form.name.trim().length < 3) {
      errs.name = 'Name must be at least 3 characters';
    } else if (!nameRegex.test(form.name.trim())) {
      errs.name = 'Name must contain only alphabets and spaces';
    }

    if (!form.email.trim()) {
      errs.email = 'Email is required';
    } else if (!emailRegex.test(form.email.trim())) {
      errs.email = 'Email is invalid';
    }

    if (!form.course) {
      errs.course = 'Course is required';
    }

    if (!form.address.trim()) {
      errs.address = 'Address is required';
    } else if (!addressRegex.test(form.address.trim())) {
      errs.address = 'Address format is invalid';
    }

    if (!form.mobile_no.trim()) {
      errs.mobile_no = 'Mobile No is required';
    } else if (!mobileRegex.test(form.mobile_no.trim())) {
      errs.mobile_no = 'Mobile No must be 10-15 digits';
    }

    if (!form.dob) {
      errs.dob = 'Date of Birth is required';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: null });
  };

  const handleSubmit = () => {
    if (!validate()) return;
    onSubmit(form);
  };

  return (
    <div className="card shadow-sm p-4 mb-4">
      <h4>{student ? 'Edit Student' : 'Add New Student'}</h4>
      <div className="mb-3">
        <label className="form-label fw-semibold">Name</label>
        <input
          type="text"
          name="name"
          className={`form-control ${errors.name ? 'is-invalid' : ''}`}
          value={form.name}
          onChange={handleChange}
          placeholder="Enter full name"
        />
        {errors.name && <div className="invalid-feedback">{errors.name}</div>}
      </div>
      <div className="mb-3">
        <label className="form-label fw-semibold">Email</label>
        <input
          type="email"
          name="email"
          className={`form-control ${errors.email || apiErrors?.email ? 'is-invalid' : ''}`}
          value={form.email}
          onChange={handleChange}
          placeholder="Enter email"
        />
        {(errors.email || apiErrors?.email) && (
          <div className="invalid-feedback">{errors.email || apiErrors.email}</div>
        )}
      </div>
      <div className="mb-3">
        <label className="form-label fw-semibold">Course</label>
        <select
          name="course"
          className={`form-select ${errors.course ? 'is-invalid' : ''}`}
          value={form.course}
          onChange={handleChange}
        >
          <option value="">Select course</option>
          {courses.map((c, i) => (
            <option key={i} value={c}>{c}</option>
          ))}
        </select>
        {errors.course && <div className="invalid-feedback">{errors.course}</div>}
      </div>
      <div className="mb-3">
        <label className="form-label fw-semibold">Address</label>
        <input
          type="text"
          name="address"
          className={`form-control ${errors.address ? 'is-invalid' : ''}`}
          value={form.address}
          onChange={handleChange}
          placeholder="Enter address"
        />
        {errors.address && <div className="invalid-feedback">{errors.address}</div>}
      </div>
      <div className="mb-3">
        <label className="form-label fw-semibold">Mobile No</label>
        <input
          type="tel"
          name="mobile_no"
          className={`form-control ${errors.mobile_no ? 'is-invalid' : ''}`}
          value={form.mobile_no}
          onChange={handleChange}
          placeholder="Enter mobile number"
        />
        {errors.mobile_no && <div className="invalid-feedback">{errors.mobile_no}</div>}
      </div>
      <div className="mb-3">
        <label className="form-label fw-semibold">Date of Birth</label>
        <input
          type="date"
          name="dob"
          className={`form-control ${errors.dob ? 'is-invalid' : ''}`}
          value={form.dob}
          onChange={handleChange}
        />
        {errors.dob && <div className="invalid-feedback">{errors.dob}</div>}
      </div>
      <div className="d-flex justify-content-end">
        <button className="btn btn-secondary me-2" onClick={onCancel}>Cancel</button>
        <button className="btn btn-primary" onClick={handleSubmit}>{student ? 'Update' : 'Add'}</button>
      </div>
    </div>
  );
}

export default StudentForm;