import React from 'react';

function StudentList({ students, onEdit, onDelete }) {
  if (students.length === 0) return <p className="text-center">No students found.</p>;

  return (
    <div className="table-responsive shadow-sm rounded">
      <table className="table table-striped table-hover align-middle mb-0">
        <thead className="table-primary">
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Course</th>
            <th>Address</th>
            <th>Mobile No</th>
            <th>DOB</th>
            <th style={{ minWidth: '110px' }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {students.map(s => (
            <tr key={s.id}>
              <td>{s.name}</td>
              <td>{s.email}</td>
              <td>{s.course}</td>
              <td>{s.address}</td>
              <td>{s.mobile_no}</td>
              <td>{s.dob ? new Date(s.dob).toLocaleDateString() : ''}</td>
              <td>
                <button
                  className="btn btn-sm btn-outline-primary me-2"
                  onClick={() => onEdit(s)}
                >
                  Edit
                </button>
                <button
                  className="btn btn-sm btn-outline-danger"
                  onClick={() => onDelete(s.id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default StudentList;
